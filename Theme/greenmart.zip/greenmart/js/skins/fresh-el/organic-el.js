'use strict';

class Feature {
  constructor() {
    this._initFeature();
  }

  _initFeature() {}

}

jQuery(document).ready(() => {
  new Feature();
});
