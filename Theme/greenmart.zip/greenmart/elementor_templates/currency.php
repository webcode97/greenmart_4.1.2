<?php 
/**
 * Templates Name: Elementor
 * Widget: Currency
 */
    
?>
<div <?php echo $this->get_render_attribute_string('wrapper'); ?>>
    <?php $this->greenmart_currency(); ?>
</div>